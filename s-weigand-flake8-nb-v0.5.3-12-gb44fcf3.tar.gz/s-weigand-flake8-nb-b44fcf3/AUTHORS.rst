=======
Credits
=======

Many thanks go to the creators and contributors of flake8_.
Which inspired me to write this hack on top of it and supplies nearly all
of the functionality.

This packages skeleton was created with Cookiecutter_ and the
`audreyr/cookiecutter-pypackage`_ project template.

The idea to use cell tags was inspired by the use of cell tags in nbval_.


.. _flake8: https://github.com/pycqa/flake8
.. _Cookiecutter: https://github.com/cookiecutter/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
.. _nbval: https://github.com/computationalmodelling/nbval
