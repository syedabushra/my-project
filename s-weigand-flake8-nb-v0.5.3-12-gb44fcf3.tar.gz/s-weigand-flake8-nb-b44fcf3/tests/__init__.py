"""Unit test package for flake8_nb."""
import os

TEST_NOTEBOOK_BASE_PATH = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "data", "notebooks")
)
