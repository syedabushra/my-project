Welcome to flake8-nb's documentation!
=====================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   readme
   installation
   usage
   examples
   api_docs
   contributing
   authors
   changelog

Indices and tables
==================
* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
