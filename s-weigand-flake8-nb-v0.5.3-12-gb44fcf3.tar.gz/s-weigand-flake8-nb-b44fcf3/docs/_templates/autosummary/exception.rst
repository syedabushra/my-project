{{ name  | escape | underline }}

.. autoexception:: {{ fullname }}
