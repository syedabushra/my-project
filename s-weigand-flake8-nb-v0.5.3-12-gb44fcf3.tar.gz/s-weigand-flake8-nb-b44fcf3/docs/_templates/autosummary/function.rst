{{ name  | escape | underline }}

.. autofunction:: {{ fullname }}
