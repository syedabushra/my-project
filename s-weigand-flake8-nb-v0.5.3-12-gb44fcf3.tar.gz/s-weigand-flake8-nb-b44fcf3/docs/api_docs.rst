==============
Inner workings
==============

This is the detailed documentation of the inner workings of ``flake8_nb``.

.. autosummary::
    :toctree: api
    :recursive:

    flake8_nb
